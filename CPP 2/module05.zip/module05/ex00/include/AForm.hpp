// dummy forward decl to satisfy include in Bureaucrat.cpp
class AForm;