#ifndef IRC_HPP
#define IRC_HPP

#include <string>

namespace IRC {
    static const std::string ServerName = "irc.local";
    static const size_t      MaxLineLen = 512; // including CRLF
    static const char*       CRLF = "\r\n";
    std::string itoa(int n);
}

#endif // IRC_HPP
