#ifndef CHANNEL_HPP
#define CHANNEL_HPP

#include <string>
#include <set>

class Channel {
public:
    Channel();
    Channel(const std::string &name);
    Channel(const Channel &o);
    Channel &operator=(const Channel &o);
    ~Channel();

    const std::string &name() const;
    const std::string &topic() const;
    void setTopic(const std::string &t);

    bool has(int fd) const;
    void add(int fd);
    void remove(int fd);
    const std::set<int> &users() const;

    bool isOp(int fd) const;
    void makeOp(int fd);
    void deop(int fd);

    bool mode_n;
    bool mode_t;
    bool mode_i;
    bool mode_k;
    bool mode_l;

    std::string key;
    int         limit;

private:
    std::string  _name;
    std::string  _topic;
    std::set<int> _users;
    std::set<int> _ops;
};

#endif // CHANNEL_HPP
