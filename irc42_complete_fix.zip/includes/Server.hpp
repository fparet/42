#ifndef SERVER_HPP
#define SERVER_HPP

#include <map>
#include <string>
#include <vector>
#include <set>
#include "Poller.hpp"
#include "Client.hpp"
#include "Channel.hpp"

class Server {
public:
    Server();
    Server(const Server &o);
    Server &operator=(const Server &o);
    ~Server();

    void init(int port, const std::string &password);
    void run();

private:
    int                      _listenFd;
    int                      _port;
    std::string              _password;
    Poller                   _poller;
    std::map<int, Client>    _clients;
    std::map<std::string, Channel> _channels;

    void setupListenSocket();
    void handleEvents();
    void acceptNew();
    void handleClientReadable(int fd);
    void handleClientWritable(int fd);
    void closeClient(int fd);

    void sendLine(int fd, const std::string &line);
    void sendFrom(int fd, const std::string &line);
    void sendToChan(const std::string &chan, int fromFd, const std::string &msg);
    void tryRegister(int fd);

    void handleCommand(int fd, const std::string &raw);
    void cmd_PASS(int fd, const std::vector<std::string> &params);
    void cmd_NICK(int fd, const std::vector<std::string> &params);
    void cmd_USER(int fd, const std::vector<std::string> &params);
    void cmd_PING(int fd, const std::vector<std::string> &params);
    void cmd_QUIT(int fd, const std::vector<std::string> &params);
    void cmd_JOIN(int fd, const std::vector<std::string> &params);
    void cmd_PART(int fd, const std::vector<std::string> &params);
    void cmd_PRIVMSG(int fd, const std::vector<std::string> &params, bool isNotice);
    void cmd_TOPIC(int fd, const std::vector<std::string> &params);
    void cmd_MODE(int fd, const std::vector<std::string> &params);
    void cmd_KICK(int fd, const std::vector<std::string> &params);

    bool isValidNick(const std::string &nick) const;
    bool nickInUse(const std::string &nick) const;
};

#endif // SERVER_HPP
