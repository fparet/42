#ifndef CLIENT_HPP
#define CLIENT_HPP

#include <string>
#include <set>

class Client {
public:
    Client();
    Client(int fd);
    Client(const Client &o);
    Client &operator=(const Client &o);
    ~Client();

    int  getFd() const;
    bool isClosed() const;

    void appendRecv(const char *data, size_t len);
    bool extractLine(std::string &outLine);
    void queueSend(const std::string &data);
    bool hasPendingSend() const;
    const std::string &sendBuffer() const;
    void consumeSend(size_t n);
    void close();

    void setNick(const std::string &n);
    void setUser(const std::string &u);
    void setReal(const std::string &r);
    const std::string &nick() const;
    const std::string &user() const;
    const std::string &real() const;
    bool isRegistered() const;
    void setPassed(bool v);
    bool passed() const;

    std::set<std::string> &channels();
    const std::set<std::string> &channels() const;

private:
    int         _fd;
    std::string _recv;
    std::string _send;
    bool        _closed;

    std::string _nick;
    std::string _user;
    std::string _real;
    bool        _passed;
    std::set<std::string> _channels;
};

#endif // CLIENT_HPP
