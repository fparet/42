#ifndef POLLER_HPP
#define POLLER_HPP

#include <vector>
#include <poll.h>

class Poller {
public:
    Poller();
    Poller(const Poller &o);
    Poller &operator=(const Poller &o);
    ~Poller();

    void add(int fd, short events);
    void mod(int fd, short events);
    void del(int fd);
    int  wait(int timeout_ms);
    short revents(int fd) const;

private:
    std::vector<struct pollfd> _pfds;
};

#endif // POLLER_HPP
