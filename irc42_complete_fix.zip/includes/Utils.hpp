#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>
#include <vector>

namespace Utils {
    std::string trimCRLF(const std::string &s);
    std::string toUpper(const std::string &s);
    void split(const std::string &s, char delim, std::vector<std::string> &out);
    bool startsWith(const std::string &s, const std::string &prefix);
    std::string safeLine(const std::string &s);
}

#endif // UTILS_HPP
