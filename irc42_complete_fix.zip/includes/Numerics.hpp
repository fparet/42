#ifndef NUMERICS_HPP
#define NUMERICS_HPP

#include <string>
#include <vector>

namespace Numerics {
    std::string numeric(const std::string &server, int code,
                        const std::string &target,
                        const std::vector<std::string> &params,
                        const std::string &trailing);
    std::string RPL_WELCOME(const std::string &server, const std::string &nick);
    std::string RPL_YOURHOST(const std::string &server, const std::string &nick);
    std::string RPL_CREATED(const std::string &server, const std::string &nick);
    std::string ERR_NOSUCHNICK(const std::string &server, const std::string &nick, const std::string &bad);
    std::string ERR_NOSUCHCHANNEL(const std::string &server, const std::string &nick, const std::string &chan);
    std::string ERR_CANNOTSENDTOCHAN(const std::string &server, const std::string &nick, const std::string &chan);
    std::string ERR_NEEDMOREPARAMS(const std::string &server, const std::string &nick, const std::string &cmd);
    std::string ERR_ALREADYREGISTRED(const std::string &server, const std::string &nick);
    std::string ERR_PASSWDMISMATCH(const std::string &server, const std::string &nick);
    std::string ERR_NONICKNAMEGIVEN(const std::string &server, const std::string &nick);
    std::string ERR_ERRONEUSNICKNAME(const std::string &server, const std::string &nick, const std::string &bad);
    std::string ERR_NICKNAMEINUSE(const std::string &server, const std::string &nick, const std::string &bad);
    std::string ERR_NOTONCHANNEL(const std::string &server, const std::string &nick, const std::string &chan);
    std::string ERR_USERNOTINCHANNEL(const std::string &server, const std::string &nick, const std::string &user, const std::string &chan);
    std::string ERR_NOTREGISTERED(const std::string &server, const std::string &nick);
    std::string ERR_CHANOPRIVSNEEDED(const std::string &server, const std::string &nick, const std::string &chan);
    std::string RPL_NOTOPIC(const std::string &server, const std::string &nick, const std::string &chan);
    std::string RPL_TOPIC(const std::string &server, const std::string &nick, const std::string &chan, const std::string &topic);
}

#endif // NUMERICS_HPP
