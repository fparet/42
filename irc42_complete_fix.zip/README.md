# IRC42 — C++98 IRC Server (ft_irc-compatible)

- C++98, headers/sources séparés, forme de Coplien.
- `poll(2)` non-bloquant, messages **CRLF** ≤ **512 octets**.
- PASS/NICK/USER (inscription), JOIN/PART, PRIVMSG/NOTICE, TOPIC, MODE (+n/+t/+i/+k/+l), KICK, PING/PONG, QUIT.
- Numériques essentiels (001, 002, 003, 331, 332, 401, 403, 404, 411, 412, 431, 432, 433, 441, 442, 451, 461, 462, 464, 482...).

## Build & Run
```bash
make
./ircserv 6667 pass
```

## Test rapide
```bash
python3 tests/run_tests.py --port 6667 --password pass
```
