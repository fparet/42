#include "IRC.hpp"
#include <sstream>
std::string IRC::itoa(int n) { std::ostringstream oss; oss << n; return oss.str(); }
