#include "Client.hpp"
#include <unistd.h>

Client::Client() : _fd(-1), _recv(), _send(), _closed(false), _nick(), _user(), _real(), _passed(false), _channels() {}
Client::Client(int fd) : _fd(fd), _recv(), _send(), _closed(false), _nick(), _user(), _real(), _passed(false), _channels() {}
Client::Client(const Client &o) : _fd(o._fd), _recv(o._recv), _send(o._send), _closed(o._closed),
    _nick(o._nick), _user(o._user), _real(o._real), _passed(o._passed), _channels(o._channels) {}
Client &Client::operator=(const Client &o) {
    if (this!=&o) {
        _fd=o._fd; _recv=o._recv; _send=o._send; _closed=o._closed;
        _nick=o._nick; _user=o._user; _real=o._real; _passed=o._passed; _channels=o._channels;
    }
    return *this;
}
Client::~Client() {}

int Client::getFd() const { return _fd; }
bool Client::isClosed() const { return _closed; }
void Client::appendRecv(const char *data, size_t len) { _recv.append(data, len); }
bool Client::extractLine(std::string &outLine) {
    std::string::size_type pos = _recv.find("\r\n");
    if (pos == std::string::npos) { pos = _recv.find('\n'); if (pos == std::string::npos) return false; outLine = _recv.substr(0, pos+1); _recv.erase(0, pos+1); return true; }
    outLine = _recv.substr(0, pos+2); _recv.erase(0, pos+2); return true;
}
void Client::queueSend(const std::string &data) { _send.append(data); }
bool Client::hasPendingSend() const { return !_send.empty(); }
const std::string &Client::sendBuffer() const { return _send; }
void Client::consumeSend(size_t n) { _send.erase(0, n); }
void Client::close() { if (!_closed) { _closed = true; if (_fd >= 0) ::close(_fd); _fd = -1; } }
void Client::setNick(const std::string &n) { _nick = n; }
void Client::setUser(const std::string &u) { _user = u; }
void Client::setReal(const std::string &r) { _real = r; }
const std::string &Client::nick() const { return _nick; }
const std::string &Client::user() const { return _user; }
const std::string &Client::real() const { return _real; }
bool Client::isRegistered() const { return _passed && !_nick.empty() && !_user.empty(); }
void Client::setPassed(bool v) { _passed = v; }
bool Client::passed() const { return _passed; }
std::set<std::string> &Client::channels() { return _channels; }
const std::set<std::string> &Client::channels() const { return _channels; }
