#include "Server.hpp"
#include "Utils.hpp"
#include "Parser.hpp"
#include "IRC.hpp"
#include "Numerics.hpp"

#include <stdexcept>
#include <cstring>
#include <cerrno>
#include <cstdio>
#include <vector>
#include <sstream>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <unistd.h>

static int setNonBlocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) return -1;
    if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) return -1;
    return 0;
}

Server::Server() : _listenFd(-1), _port(0), _password(), _poller(), _clients(), _channels() {}
Server::Server(const Server &o)
: _listenFd(o._listenFd), _port(o._port), _password(o._password), _poller(o._poller), _clients(o._clients), _channels(o._channels) {}
Server &Server::operator=(const Server &o) {
    if (this!=&o) { _listenFd=o._listenFd; _port=o._port; _password=o._password; _poller=o._poller; _clients=o._clients; _channels=o._channels; }
    return *this;
}
Server::~Server() {
    if (_listenFd >= 0) ::close(_listenFd);
    for (std::map<int, Client>::iterator it=_clients.begin(); it!=_clients.end(); ++it) it->second.close();
}

void Server::init(int port, const std::string &password) { _port = port; _password = password; setupListenSocket(); }

void Server::setupListenSocket() {
    _listenFd = ::socket(AF_INET, SOCK_STREAM, 0);
    if (_listenFd < 0) throw std::runtime_error("socket() failed");
    int yes = 1; ::setsockopt(_listenFd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    struct sockaddr_in addr; std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY); addr.sin_port = htons(_port);
    if (::bind(_listenFd, (struct sockaddr*)&addr, sizeof(addr)) < 0) throw std::runtime_error("bind() failed");
    if (::listen(_listenFd, 128) < 0) throw std::runtime_error("listen() failed");
    if (setNonBlocking(_listenFd) < 0) throw std::runtime_error("fcntl() failed");
    _poller.add(_listenFd, POLLIN);
    std::printf("[server] listening on port %d\n", _port);
}

void Server::run() {
    while (true) {
        int n = _poller.wait(1000); (void)n;
        handleEvents();
    }
}

void Server::handleEvents() {
    short ev = _poller.revents(_listenFd);
    if (ev & POLLIN) acceptNew();
    std::vector<int> fds; fds.reserve(_clients.size());
    for (std::map<int, Client>::iterator it=_clients.begin(); it!=_clients.end(); ++it) fds.push_back(it->first);
    for (size_t i=0;i<fds.size();++i) {
        int fd = fds[i];
        short re = _poller.revents(fd);
        if (re & POLLIN) handleClientReadable(fd);
        if (re & POLLOUT) handleClientWritable(fd);
        if (re & (POLLERR | POLLHUP | POLLNVAL)) closeClient(fd);
    }
}

void Server::acceptNew() {
    while (true) {
        int cfd = ::accept(_listenFd, 0, 0);
        if (cfd < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            std::perror("accept"); break;
        }
        setNonBlocking(cfd);
        _clients.insert(std::make_pair(cfd, Client(cfd)));
        _poller.add(cfd, POLLIN);
        sendLine(cfd, ":" + IRC::ServerName + " NOTICE * :Welcome to IRC42 server" + std::string(IRC::CRLF));
        std::printf("[server] new client fd=%d\n", cfd);
    }
}

void Server::handleClientReadable(int fd) {
    char buf[4096];
    ssize_t r = ::recv(fd, buf, sizeof(buf), 0);
    if (r <= 0) { closeClient(fd); return; }
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it == _clients.end()) return;
    it->second.appendRecv(buf, (size_t)r);

    std::string line;
    while (it->second.extractLine(line)) {
        if (line.size() > IRC::MaxLineLen) line = Utils::safeLine(line.substr(0, IRC::MaxLineLen));
        handleCommand(fd, line);
    }

    if (_clients.find(fd) != _clients.end() && _clients[fd].hasPendingSend())
        _poller.mod(fd, POLLIN | POLLOUT);
}

void Server::handleClientWritable(int fd) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it == _clients.end()) return;
    const std::string &out = it->second.sendBuffer();
    if (out.empty()) { _poller.mod(fd, POLLIN); return; }
    ssize_t s = ::send(fd, out.data(), out.size(), 0);
    if (s < 0) { if (errno == EAGAIN || errno == EWOULDBLOCK) return; closeClient(fd); return; }
    it->second.consumeSend((size_t)s);
    if (!it->second.hasPendingSend()) _poller.mod(fd, POLLIN);
}

void Server::closeClient(int fd) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it != _clients.end()) {
        for (std::set<std::string>::const_iterator ci=it->second.channels().begin(); ci!=it->second.channels().end(); ++ci) {
            std::map<std::string, Channel>::iterator chIt = _channels.find(*ci);
            if (chIt != _channels.end()) chIt->second.remove(fd);
        }
        it->second.close();
        _clients.erase(it);
    }
    _poller.del(fd);
    std::printf("[server] closed fd=%d\n", fd);
}

void Server::sendLine(int fd, const std::string &line) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it == _clients.end()) return;
    it->second.queueSend(Utils::safeLine(line));
}

void Server::sendFrom(int fd, const std::string &line) { sendLine(fd, line); }

void Server::sendToChan(const std::string &chan, int fromFd, const std::string &msg) {
    std::map<std::string, Channel>::iterator ci = _channels.find(chan);
    if (ci==_channels.end()) return;
    Channel &c = ci->second;
    for (std::set<int>::const_iterator it=c.users().begin(); it!=c.users().end(); ++it) {
        if (*it == fromFd) continue;
        sendLine(*it, msg);
    }
}
