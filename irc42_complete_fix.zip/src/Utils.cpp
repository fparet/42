#include "Utils.hpp"
#include "IRC.hpp"

std::string Utils::trimCRLF(const std::string &s) {
    std::string t = s;
    while (!t.empty() && (t[t.size()-1] == '\n' || t[t.size()-1] == '\r')) t.erase(t.end()-1);
    return t;
}
std::string Utils::toUpper(const std::string &s) {
    std::string r = s;
    for (std::string::size_type i=0;i<r.size();++i) {
        char c = r[i];
        if (c >= 'a' && c <= 'z') r[i] = c - ('a' - 'A');
    }
    return r;
}
void Utils::split(const std::string &s, char d, std::vector<std::string> &out) {
    out.clear(); std::string cur;
    for (std::string::size_type i=0;i<s.size();++i) { if (s[i]==d){ out.push_back(cur); cur.clear(); } else cur+=s[i]; }
    out.push_back(cur);
}
bool Utils::startsWith(const std::string &s, const std::string &p) {
    if (p.size() > s.size()) return false; return s.compare(0, p.size(), p) == 0;
}
std::string Utils::safeLine(const std::string &s) {
    std::string line = s;
    if (line.size()<2 || line[line.size()-2] != '\r' || line[line.size()-1] != '\n') line += IRC::CRLF;
    if (line.size() > IRC::MaxLineLen) {
        std::string core = line.substr(0, IRC::MaxLineLen);
        if (core.size() >= 2) { core[IRC::MaxLineLen-2] = '\r'; core[IRC::MaxLineLen-1] = '\n'; }
        return core;
    }
    return line;
}
