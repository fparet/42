#include "Parser.hpp"
#include "Utils.hpp"

ParsedMessage Parser::parse(const std::string &raw_) {
    ParsedMessage res;
    std::string raw = Utils::trimCRLF(raw_);
    std::string s = raw;
    if (!s.empty() && s[0] == ':') {
        std::string::size_type sp = s.find(' ');
        if (sp != std::string::npos) { res.prefix = s.substr(1, sp-1); s.erase(0, sp+1); }
        else s.erase();
    }
    std::string::size_type sp = s.find(' ');
    if (sp == std::string::npos) { res.command = Utils::toUpper(s); return res; }
    res.command = Utils::toUpper(s.substr(0, sp)); s.erase(0, sp+1);
    while (!s.empty()) {
        if (s[0] == ':') { res.params.push_back(s.substr(1)); break; }
        std::string::size_type sp2 = s.find(' ');
        if (sp2 == std::string::npos) { if (!s.empty()) res.params.push_back(s); break; }
        else { res.params.push_back(s.substr(0, sp2)); s.erase(0, sp2+1); }
    }
    return res;
}
