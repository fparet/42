#include "Server.hpp"
#include "Parser.hpp"
#include "Utils.hpp"
#include "IRC.hpp"
#include "Numerics.hpp"

#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <cstdlib>

bool Server::isValidNick(const std::string &nick) const {
    if (nick.empty()) return false;
    const std::string allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ[]\\`_^{}|0123456789-";
    if (allowed.find(nick[0]) == std::string::npos) return false;
    for (size_t i=1;i<nick.size();++i) if (allowed.find(nick[i]) == std::string::npos) return false;
    return true;
}
bool Server::nickInUse(const std::string &nick) const {
    for (std::map<int, Client>::const_iterator it=_clients.begin(); it!=_clients.end(); ++it)
        if (it->second.nick() == nick) return true;
    return false;
}
void Server::tryRegister(int fd) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it==_clients.end()) return;
    Client &cl = it->second;
    if (cl.isRegistered()) {
        sendLine(fd, Numerics::RPL_WELCOME(IRC::ServerName, cl.nick()));
        sendLine(fd, Numerics::RPL_YOURHOST(IRC::ServerName, cl.nick()));
        sendLine(fd, Numerics::RPL_CREATED(IRC::ServerName, cl.nick()));
    }
}
void Server::handleCommand(int fd, const std::string &raw) {
    ParsedMessage m = Parser::parse(raw);
    const std::string cmd = Utils::toUpper(m.command);
    if (cmd == "PASS") cmd_PASS(fd, m.params);
    else if (cmd == "NICK") cmd_NICK(fd, m.params);
    else if (cmd == "USER") cmd_USER(fd, m.params);
    else if (cmd == "PING") cmd_PING(fd, m.params);
    else if (cmd == "QUIT") cmd_QUIT(fd, m.params);
    else if (cmd == "JOIN") cmd_JOIN(fd, m.params);
    else if (cmd == "PART") cmd_PART(fd, m.params);
    else if (cmd == "PRIVMSG") cmd_PRIVMSG(fd, m.params, false);
    else if (cmd == "NOTICE") cmd_PRIVMSG(fd, m.params, true);
    else if (cmd == "TOPIC") cmd_TOPIC(fd, m.params);
    else if (cmd == "MODE") cmd_MODE(fd, m.params);
    else if (cmd == "KICK") cmd_KICK(fd, m.params);
}
void Server::cmd_PASS(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it==_clients.end()) return;
    Client &cl = it->second;
    if (cl.isRegistered()) { sendLine(fd, Numerics::ERR_ALREADYREGISTRED(IRC::ServerName, cl.nick())); return; }
    if (params.empty()) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, "*", "PASS")); return; }
    if (params[0] != _password) { sendLine(fd, Numerics::ERR_PASSWDMISMATCH(IRC::ServerName, "*")); return; }
    cl.setPassed(true);
    tryRegister(fd);
}
void Server::cmd_NICK(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it==_clients.end()) return;
    Client &cl = it->second;
    const std::string curNick = cl.nick();
    if (params.empty()) { sendLine(fd, Numerics::ERR_NONICKNAMEGIVEN(IRC::ServerName, (curNick.empty()? "*":curNick))); return; }
    std::string newNick = params[0];
    if (!isValidNick(newNick)) { sendLine(fd, Numerics::ERR_ERRONEUSNICKNAME(IRC::ServerName, (curNick.empty()? "*":curNick), newNick)); return; }
    if (nickInUse(newNick) && newNick != curNick) { sendLine(fd, Numerics::ERR_NICKNAMEINUSE(IRC::ServerName, (curNick.empty()? "*":curNick), newNick)); return; }
    bool wasReg = cl.isRegistered();
    cl.setNick(newNick);
    if (wasReg) {
        std::ostringstream oss; oss << ":" << curNick << "!~" << cl.user() << "@localhost NICK :" << newNick << IRC::CRLF;
        for (std::set<std::string>::const_iterator ci=cl.channels().begin(); ci!=cl.channels().end(); ++ci) sendToChan(*ci, fd, oss.str());
    }
    tryRegister(fd);
}
void Server::cmd_USER(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd);
    if (it==_clients.end()) return;
    Client &cl = it->second;
    if (cl.isRegistered()) { sendLine(fd, Numerics::ERR_ALREADYREGISTRED(IRC::ServerName, cl.nick())); return; }
    if (params.size() < 4) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, (cl.nick().empty()? "*":cl.nick()), "USER")); return; }
    cl.setUser(params[0]); cl.setReal(params[3]); tryRegister(fd);
}
void Server::cmd_PING(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    const std::string nick = it->second.nick().empty()? "*":it->second.nick();
    if (params.empty()) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, nick, "PING")); return; }
    std::ostringstream oss; oss << ":" << IRC::ServerName << " PONG :" << params[0] << IRC::CRLF; sendLine(fd, oss.str());
}
void Server::cmd_QUIT(int fd, const std::vector<std::string> &params) { (void)params; closeClient(fd); }
void Server::cmd_JOIN(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    Client &cl = it->second;
    if (!cl.isRegistered()) { sendLine(fd, Numerics::ERR_NOTREGISTERED(IRC::ServerName, "*")); return; }
    if (params.empty()) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "JOIN")); return; }
    std::vector<std::string> names; Utils::split(params[0], ',', names);
    std::vector<std::string> keys; if (params.size() >= 2) Utils::split(params[1], ',', keys);
    for (size_t i=0;i<names.size();++i) {
        std::string chan = names[i];
        if (chan.empty() || chan[0] != '#') { sendLine(fd, Numerics::ERR_NOSUCHCHANNEL(IRC::ServerName, cl.nick(), chan)); continue; }
        Channel &c = _channels[chan]; if (c.name().empty()) c = Channel(chan);
        if (c.mode_k) { std::string key = (i<keys.size()? keys[i] : ""); if (key != c.key) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "JOIN")); continue; } }
        if (c.mode_l && (int)c.users().size() >= c.limit) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "JOIN")); continue; }
        if (!c.has(fd)) {
            c.add(fd); if (c.users().size()==1) c.makeOp(fd);
            cl.channels().insert(chan);
            std::ostringstream joinTag; joinTag << ":" << cl.nick() << "!~" << cl.user() << "@localhost JOIN " << chan << IRC::CRLF;
            sendToChan(chan, fd, joinTag.str()); sendLine(fd, joinTag.str());
            if (c.topic().empty()) sendLine(fd, Numerics::RPL_NOTOPIC(IRC::ServerName, cl.nick(), chan));
            else sendLine(fd, Numerics::RPL_TOPIC(IRC::ServerName, cl.nick(), chan, c.topic()));
        }
    }
}
void Server::cmd_PART(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    Client &cl = it->second;
    if (params.empty()) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "PART")); return; }
    std::string chan = params[0];
    std::map<std::string, Channel>::iterator ci = _channels.find(chan);
    if (ci==_channels.end()) { sendLine(fd, Numerics::ERR_NOSUCHCHANNEL(IRC::ServerName, cl.nick(), chan)); return; }
    Channel &c = ci->second;
    if (!c.has(fd)) { sendLine(fd, Numerics::ERR_NOTONCHANNEL(IRC::ServerName, cl.nick(), chan)); return; }
    std::ostringstream tag; tag << ":" << cl.nick() << "!~" << cl.user() << "@localhost PART " << chan << IRC::CRLF;
    sendToChan(chan, fd, tag.str()); sendLine(fd, tag.str()); c.remove(fd); cl.channels().erase(chan);
}
void Server::cmd_PRIVMSG(int fd, const std::vector<std::string> &params, bool isNotice) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    Client &cl = it->second; const std::string nick = cl.nick().empty()? "*":cl.nick();
    if (params.size() < 2) { if (!isNotice) sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, nick, isNotice? "NOTICE":"PRIVMSG")); return; }
    std::string target = params[0]; std::string text = params[1];
    std::ostringstream msg; msg << ":" << cl.nick() << "!~" << cl.user() << "@localhost " << (isNotice?"NOTICE":"PRIVMSG") << " " << target << " :" << text << IRC::CRLF;
    if (!target.empty() && target[0]=='#') {
        std::map<std::string, Channel>::iterator ci = _channels.find(target);
        if (ci==_channels.end()) { if (!isNotice) sendLine(fd, Numerics::ERR_NOSUCHCHANNEL(IRC::ServerName, nick, target)); return; }
        Channel &c = ci->second;
        if (c.mode_n && !c.has(fd)) { if (!isNotice) sendLine(fd, Numerics::ERR_CANNOTSENDTOCHAN(IRC::ServerName, nick, target)); return; }
        sendToChan(target, fd, msg.str());
    } else {
        int toFd = -1; for (std::map<int, Client>::const_iterator it2=_clients.begin(); it2!=_clients.end(); ++it2) if (it2->second.nick() == target) { toFd = it2->first; break; }
        if (toFd < 0) { if (!isNotice) sendLine(fd, Numerics::ERR_NOSUCHNICK(IRC::ServerName, nick, target)); return; }
        sendLine(toFd, msg.str());
    }
}
void Server::cmd_TOPIC(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    Client &cl = it->second;
    if (params.empty()) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "TOPIC")); return; }
    std::string chan = params[0];
    std::map<std::string, Channel>::iterator ci = _channels.find(chan);
    if (ci==_channels.end()) { sendLine(fd, Numerics::ERR_NOSUCHCHANNEL(IRC::ServerName, cl.nick(), chan)); return; }
    Channel &c = ci->second;
    if (params.size()==1) { if (c.topic().empty()) sendLine(fd, Numerics::RPL_NOTOPIC(IRC::ServerName, cl.nick(), chan)); else sendLine(fd, Numerics::RPL_TOPIC(IRC::ServerName, cl.nick(), chan, c.topic())); return; }
    if (c.mode_t && !c.isOp(fd)) { sendLine(fd, Numerics::ERR_CHANOPRIVSNEEDED(IRC::ServerName, cl.nick(), chan)); return; }
    c.setTopic(params[1]);
    std::ostringstream tag; tag << ":" << cl.nick() << "!~" << cl.user() << "@localhost TOPIC " << chan << " :" << c.topic() << IRC::CRLF;
    sendToChan(chan, fd, tag.str()); sendLine(fd, tag.str());
}
void Server::cmd_MODE(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    Client &cl = it->second;
    if (params.empty()) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "MODE")); return; }
    std::string target = params[0];
    if (target.empty() || target[0] != '#') { return; }
    std::map<std::string, Channel>::iterator ci = _channels.find(target);
    if (ci==_channels.end()) { sendLine(fd, Numerics::ERR_NOSUCHCHANNEL(IRC::ServerName, cl.nick(), target)); return; }
    Channel &c = ci->second;
    if (params.size()==1) { return; }
    if (!c.isOp(fd)) { sendLine(fd, Numerics::ERR_CHANOPRIVSNEEDED(IRC::ServerName, cl.nick(), target)); return; }
    bool add = true; size_t pidx = 2; const std::string &modes = params[1];
    for (size_t i=0;i<modes.size();++i) {
        char ch = modes[i];
        if (ch == '+') { add = true; continue; }
        if (ch == '-') { add = false; continue; }
        if (ch == 'n') c.mode_n = add;
        else if (ch == 't') c.mode_t = add;
        else if (ch == 'i') c.mode_i = add;
        else if (ch == 'k') { if (add) { if (pidx < params.size()) { c.mode_k = true; c.key = params[pidx++]; } } else { c.mode_k = false; c.key.clear(); } }
        else if (ch == 'l') { if (add) { if (pidx < params.size()) { c.mode_l = true; c.limit = std::atoi(params[pidx++].c_str()); } } else { c.mode_l = false; c.limit = 0; } }
    }
}
void Server::cmd_KICK(int fd, const std::vector<std::string> &params) {
    std::map<int, Client>::iterator it = _clients.find(fd); if (it==_clients.end()) return;
    Client &cl = it->second;
    if (params.size() < 2) { sendLine(fd, Numerics::ERR_NEEDMOREPARAMS(IRC::ServerName, cl.nick(), "KICK")); return; }
    std::string chan = params[0]; std::string victim = params[1];
    std::map<std::string, Channel>::iterator ci = _channels.find(chan);
    if (ci==_channels.end()) { sendLine(fd, Numerics::ERR_NOSUCHCHANNEL(IRC::ServerName, cl.nick(), chan)); return; }
    Channel &c = ci->second;
    if (!c.isOp(fd)) { sendLine(fd, Numerics::ERR_CHANOPRIVSNEEDED(IRC::ServerName, cl.nick(), chan)); return; }
    int vfd = -1; for (std::map<int, Client>::iterator jt=_clients.begin(); jt!=_clients.end(); ++jt) if (jt->second.nick() == victim) { vfd = jt->first; break; }
    if (vfd < 0) { sendLine(fd, Numerics::ERR_NOSUCHNICK(IRC::ServerName, cl.nick(), victim)); return; }
    if (!c.has(vfd)) { sendLine(fd, Numerics::ERR_USERNOTINCHANNEL(IRC::ServerName, cl.nick(), victim, chan)); return; }
    std::ostringstream tag; tag << ":" << cl.nick() << "!~" << cl.user() << "@localhost KICK " << chan << " " << victim << " :kick" << IRC::CRLF;
    sendToChan(chan, fd, tag.str()); sendLine(vfd, tag.str()); c.remove(vfd); _clients[vfd].channels().erase(chan);
}
