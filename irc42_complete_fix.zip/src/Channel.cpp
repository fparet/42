#include "Channel.hpp"

Channel::Channel() : _name(), _topic(), _users(), _ops(),
    mode_n(true), mode_t(false), mode_i(false), mode_k(false), mode_l(false), key(), limit(0) {}
Channel::Channel(const std::string &n) : _name(n), _topic(), _users(), _ops(),
    mode_n(true), mode_t(false), mode_i(false), mode_k(false), mode_l(false), key(), limit(0) {}
Channel::Channel(const Channel &o) : _name(o._name), _topic(o._topic), _users(o._users), _ops(o._ops),
    mode_n(o.mode_n), mode_t(o.mode_t), mode_i(o.mode_i), mode_k(o.mode_k), mode_l(o.mode_l), key(o.key), limit(o.limit) {}
Channel &Channel::operator=(const Channel &o) { if (this!=&o){ _name=o._name; _topic=o._topic; _users=o._users; _ops=o._ops; mode_n=o.mode_n; mode_t=o.mode_t; mode_i=o.mode_i; mode_k=o.mode_k; mode_l=o.mode_l; key=o.key; limit=o.limit; } return *this; }
Channel::~Channel() {}
const std::string &Channel::name() const { return _name; }
const std::string &Channel::topic() const { return _topic; }
void Channel::setTopic(const std::string &t) { _topic = t; }
bool Channel::has(int fd) const { return _users.find(fd) != _users.end(); }
void Channel::add(int fd) { _users.insert(fd); }
void Channel::remove(int fd) { _users.erase(fd); _ops.erase(fd); }
const std::set<int> &Channel::users() const { return _users; }
bool Channel::isOp(int fd) const { return _ops.find(fd) != _ops.end(); }
void Channel::makeOp(int fd) { _ops.insert(fd); }
void Channel::deop(int fd) { _ops.erase(fd); }
