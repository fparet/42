#include "Server.hpp"
#include <iostream>
#include <cstdlib>
static void usage(const char *prog) { std::cerr << "Usage: " << prog << " <port> <password>\n"; }
int main(int argc, char **argv) {
    if (argc != 3) { usage(argv[0]); return 1; }
    int port = std::atoi(argv[1]); if (port <= 0 || port > 65535) { std::cerr << "Invalid port\n"; return 1; }
    std::string password(argv[2]);
    try { Server s; s.init(port, password); s.run(); }
    catch (const std::exception &e) { std::cerr << "Fatal: " << e.what() << "\n"; return 1; }
    return 0;
}
