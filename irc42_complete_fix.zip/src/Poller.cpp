#include <cstddef>
#include "Poller.hpp"
Poller::Poller() : _pfds() {}
Poller::Poller(const Poller &o) : _pfds(o._pfds) {}
Poller &Poller::operator=(const Poller &o) { if (this!=&o) _pfds=o._pfds; return *this; }
Poller::~Poller() {}
void Poller::add(int fd, short ev){ struct pollfd p; p.fd=fd; p.events=ev; p.revents=0; _pfds.push_back(p); }
void Poller::mod(int fd, short ev){ for(std::size_t i=0; i<_pfds.size(); ++i) if(_pfds[i].fd==fd){ _pfds[i].events=ev; return; } }
void Poller::del(int fd){ for(std::size_t i=0; i<_pfds.size(); ++i) if(_pfds[i].fd==fd){ _pfds.erase(_pfds.begin()+i); return; } }
int Poller::wait(int t){ if(_pfds.empty()) return 0; return ::poll(&_pfds[0], _pfds.size(), t); }
short Poller::revents(int fd) const { for(std::size_t i=0; i<_pfds.size(); ++i) if(_pfds[i].fd==fd) return _pfds[i].revents; return 0; }
