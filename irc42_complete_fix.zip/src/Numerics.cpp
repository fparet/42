#include "Numerics.hpp"
#include "IRC.hpp"
#include <sstream>
#include <vector>
static std::string pad3(int code) { std::ostringstream o; if (code<100) o<<'0'; if (code<10) o<<'0'; o<<code; return o.str(); }
std::string Numerics::numeric(const std::string &server, int code, const std::string &target,
                              const std::vector<std::string> &params, const std::string &trail) {
    std::ostringstream oss;
    oss << ":" << server << " " << pad3(code) << " " << target;
    for (size_t i=0;i<params.size();++i) oss << " " << params[i];
    if (!trail.empty()) oss << " :" << trail;
    oss << IRC::CRLF;
    return oss.str();
}
std::string Numerics::RPL_WELCOME(const std::string &s, const std::string &n){ return numeric(s,1,n,std::vector<std::string>(),"Welcome to the IRC network "+n); }
std::string Numerics::RPL_YOURHOST(const std::string &s, const std::string &n){ return numeric(s,2,n,std::vector<std::string>(),"Your host is "+s); }
std::string Numerics::RPL_CREATED(const std::string &s, const std::string &n){ return numeric(s,3,n,std::vector<std::string>(),"This server was created just now"); }
std::string Numerics::ERR_NOSUCHNICK(const std::string &s,const std::string &n,const std::string &b){ std::vector<std::string> p(1,b); return numeric(s,401,n,p,"No such nick"); }
std::string Numerics::ERR_NOSUCHCHANNEL(const std::string &s,const std::string &n,const std::string &c){ std::vector<std::string> p(1,c); return numeric(s,403,n,p,"No such channel"); }
std::string Numerics::ERR_CANNOTSENDTOCHAN(const std::string &s,const std::string &n,const std::string &c){ std::vector<std::string> p(1,c); return numeric(s,404,n,p,"Cannot send to channel"); }
std::string Numerics::ERR_NEEDMOREPARAMS(const std::string &s,const std::string &n,const std::string &c){ std::vector<std::string> p(1,c); return numeric(s,461,n,p,"Not enough parameters"); }
std::string Numerics::ERR_ALREADYREGISTRED(const std::string &s,const std::string &n){ return numeric(s,462,n,std::vector<std::string>(),"You may not reregister"); }
std::string Numerics::ERR_PASSWDMISMATCH(const std::string &s,const std::string &n){ return numeric(s,464,n,std::vector<std::string>(),"Password incorrect"); }
std::string Numerics::ERR_NONICKNAMEGIVEN(const std::string &s,const std::string &n){ return numeric(s,431,n,std::vector<std::string>(),"No nickname given"); }
std::string Numerics::ERR_ERRONEUSNICKNAME(const std::string &s,const std::string &n,const std::string &b){ std::vector<std::string> p(1,b); return numeric(s,432,n,p,"Erroneous nickname"); }
std::string Numerics::ERR_NICKNAMEINUSE(const std::string &s,const std::string &n,const std::string &b){ std::vector<std::string> p(1,b); return numeric(s,433,n,p,"Nickname is already in use"); }
std::string Numerics::ERR_NOTONCHANNEL(const std::string &s,const std::string &n,const std::string &c){ std::vector<std::string> p(1,c); return numeric(s,442,n,p,"You're not on that channel"); }
std::string Numerics::ERR_USERNOTINCHANNEL(const std::string &s,const std::string &n,const std::string &u,const std::string &c){ std::vector<std::string> p; p.push_back(u); p.push_back(c); return numeric(s,441,n,p,"They aren't on that channel"); }
std::string Numerics::ERR_NOTREGISTERED(const std::string &s,const std::string &n){ return numeric(s,451,n,std::vector<std::string>(),"You have not registered"); }
std::string Numerics::ERR_CHANOPRIVSNEEDED(const std::string &s,const std::string &n,const std::string &c){ std::vector<std::string> p(1,c); return numeric(s,482,n,p,"You're not channel operator"); }
std::string Numerics::RPL_NOTOPIC(const std::string &s,const std::string &n,const std::string &c){ std::vector<std::string> p(1,c); return numeric(s,331,n,p,"No topic is set"); }
std::string Numerics::RPL_TOPIC(const std::string &s,const std::string &n,const std::string &c,const std::string &t){ std::vector<std::string> p(1,c); return numeric(s,332,n,p,t); }
