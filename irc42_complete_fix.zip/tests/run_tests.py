#!/usr/bin/env python3
import socket, time, subprocess, os, sys, signal

def recv_some(sock, timeout=1.0):
    sock.setblocking(0)
    end = time.time() + timeout
    data = b""
    while time.time() < end:
        try:
            chunk = sock.recv(4096)
            if chunk: data += chunk
            else: time.sleep(0.01)
        except BlockingIOError:
            time.sleep(0.01)
    return data.decode("utf-8", "ignore")

def send_lines(sock, lines):
    for l in lines:
        if not l.endswith("\r\n"):
            l = l + "\r\n"
        sock.sendall(l.encode("utf-8"))

def connect_and_register(port, password, nick, user, real):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", port))
    send_lines(s, [f"PASS {password}", f"NICK {nick}", f"USER {user} 0 * :{real}"])
    time.sleep(0.1)
    data = recv_some(s, 0.8)
    ok = (" 001 " in data) or ("NOTICE *" in data)
    return s, data, ok

def run(port, password):
    server = subprocess.Popen(["./ircserv", str(port), password], stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setsid)
    time.sleep(0.3)
    ok_all = True
    try:
        a, d, ok = connect_and_register(port, password, "alice", "alice", "Alice")
        b, d2, ok2 = connect_and_register(port, password, "bob", "bob", "Bob")
        ok_all &= ok and ok2

        send_lines(a, ["JOIN #test"]); time.sleep(0.1)
        send_lines(b, ["JOIN #test"]); time.sleep(0.1)

        send_lines(a, ["PRIVMSG #test :hello"])
        time.sleep(0.1)
        got = recv_some(b, 0.6)
        ok_all &= ("PRIVMSG #test :hello" in got)

        send_lines(a, ["PING :xyz"])
        pong = recv_some(a, 0.5)
        ok_all &= ("PONG :xyz" in pong)

        send_lines(a, ["TOPIC #test :greetings"])
        time.sleep(0.1)
        top = recv_some(b, 0.5)
        ok_all &= ("TOPIC #test :greetings" in top)

        send_lines(a, ["KICK #test bob :bye"])
        time.sleep(0.1)
        kicked = recv_some(b, 0.5)
        ok_all &= ("KICK #test bob" in kicked)

        send_lines(a, ["QUIT"]); send_lines(b, ["QUIT"])

    finally:
        os.killpg(os.getpgid(server.pid), signal.SIGTERM)
        try: server.wait(timeout=1.0)
        except Exception: pass

    print("RESULT:", "OK" if ok_all else "FAIL")
    return ok_all

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=6667)
    ap.add_argument("--password", type=str, default="pass")
    args = ap.parse_args()
    ok = run(args.port, args.password)
    sys.exit(0 if ok else 1)
